<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class BranchPlan extends Model
{
    protected $table = "restaurant_planes";
}
