<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class BranchVote extends Model
{
    protected $guarded = [];
}
