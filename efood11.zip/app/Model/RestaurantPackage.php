<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class RestaurantPackage extends Model
{
    protected $table = 'restaurant_packages';

}
