<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DeliveryRequest extends Model
{
    //
    protected $guarded = [];
}
